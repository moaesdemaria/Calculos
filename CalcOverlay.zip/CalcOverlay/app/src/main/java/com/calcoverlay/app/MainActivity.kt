package com.calcoverlay.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                // Repassa o resultCode/data para o Service, que usa para criar a MediaProjection
                val intent = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(OverlayService.EXTRA_RESULT_DATA, result.data)
                }
                ActivityCompat.startForegroundService(this, intent)
                Toast.makeText(this, "Janela flutuante ativada. Arraste a mira sobre os números.", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this, "Permissão de captura de tela negada.", Toast.LENGTH_SHORT).show()
            }
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) {
            checkOverlayThenRequestCapture()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        findViewById<TextView>(R.id.tvInfo).text =
            "Este app cria uma janela flutuante com uma \"mira\" que você posiciona sobre uma " +
            "expressão matemática na tela. Toque no botão de calcular dentro da mira para ler " +
            "(OCR) e resolver o cálculo automaticamente."

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            checkOverlayThenRequestCapture()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Janela flutuante desativada.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkOverlayThenRequestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
            return
        }
        // Pede autorização do sistema para capturar a tela (necessário 1x por sessão)
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
