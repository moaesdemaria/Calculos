package com.calcoverlay.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "com.calcoverlay.app.START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "calc_overlay_channel"
        private const val NOTIF_ID = 1
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val scope = CoroutineScope(Dispatchers.Main)
    private lateinit var metrics: DisplayMetrics

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        metrics = resources.displayMetrics
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            startForeground(NOTIF_ID, buildNotification())

            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

            if (resultData != null) {
                val projectionManager =
                    getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
                showOverlay()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
    }

    // ---------- UI da janela flutuante ----------

    private fun showOverlay() {
        if (overlayView != null) return

        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.overlay_target, null)
        overlayView = view

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            (220 * metrics.density).toInt(),
            (120 * metrics.density).toInt(),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 100
        params.y = 300

        windowManager.addView(view, params)

        val resultText = view.findViewById<TextView>(R.id.tvResult)
        val calcButton = view.findViewById<View>(R.id.btnCalc)
        val closeButton = view.findViewById<View>(R.id.btnClose)
        val dragHandle = view.findViewById<View>(R.id.dragHandle)

        // Arrastar a janela pela alça no topo
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }

        closeButton.setOnClickListener {
            stopSelf()
        }

        calcButton.setOnClickListener {
            resultText.text = "..."
            captureAndSolve(view, params, resultText)
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null
    }

    // ---------- Captura da área + OCR + cálculo ----------

    private fun captureAndSolve(anchorView: View, params: WindowManager.LayoutParams, resultText: TextView) {
        val projection = mediaProjection ?: run {
            resultText.text = "Sem permissão de captura"
            return
        }

        // Esconde temporariamente a janela para não capturar a própria UI
        anchorView.visibility = View.INVISIBLE

        anchorView.postDelayed({
            val reader = ImageReader.newInstance(
                metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2
            )
            imageReader = reader

            virtualDisplay = projection.createVirtualDisplay(
                "CalcOverlayCapture",
                metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )

            reader.setOnImageAvailableListener({ imgReader ->
                val image = imgReader.acquireLatestImage()
                if (image != null) {
                    val bitmap = imageToBitmap(image, metrics.widthPixels, metrics.heightPixels)
                    image.close()
                    virtualDisplay?.release()
                    imgReader.close()

                    anchorView.visibility = View.VISIBLE

                    // Recorta a região correspondente à posição da janela de mira na tela
                    val cropped = cropToOverlay(bitmap, anchorView, params)
                    runOcrAndSolve(cropped, resultText)
                }
            }, null)
        }, 150)
    }

    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width

        val bitmap = Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return Bitmap.createBitmap(bitmap, 0, 0, width, height)
    }

    private fun cropToOverlay(bitmap: Bitmap, anchorView: View, params: WindowManager.LayoutParams): Bitmap {
        // Área de leitura = miolo da janela flutuante (exclui a alça e os botões),
        // usando as coordenadas atuais na tela.
        val location = IntArray(2)
        anchorView.getLocationOnScreen(location)
        val left = location[0].coerceIn(0, bitmap.width - 1)
        val top = (location[1] + (28 * metrics.density).toInt()).coerceIn(0, bitmap.height - 1)
        val right = (left + anchorView.width).coerceAtMost(bitmap.width)
        val bottom = (top + (anchorView.height - (28 * metrics.density).toInt()) - (36 * metrics.density).toInt())
            .coerceAtMost(bitmap.height).coerceAtLeast(top + 1)

        return Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
    }

    private fun runOcrAndSolve(bitmap: Bitmap, resultText: TextView) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val input = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(input)
            .addOnSuccessListener { visionText ->
                val raw = visionText.text.replace("\n", " ").trim()
                scope.launch {
                    val solved = withContext(Dispatchers.Default) {
                        try {
                            "= ${MathEvaluator.solve(raw)}"
                        } catch (e: Exception) {
                            "Não li: \"$raw\""
                        }
                    }
                    resultText.text = solved
                }
            }
            .addOnFailureListener {
                resultText.text = "Erro no OCR"
            }
    }

    // ---------- Notificação (obrigatória para foreground service) ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Calc Overlay", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Calc Overlay ativo")
            .setContentText("Toque na mira flutuante para calcular")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()
    }
}
