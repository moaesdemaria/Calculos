package com.calcoverlay.app

import kotlin.math.*

/**
 * Avalia expressões matemáticas (+ - * / ^ % parênteses, funções comuns)
 * e resolve equações lineares simples do tipo "3x + 5 = 20".
 */
object MathEvaluator {

    class MathError(message: String) : Exception(message)

    fun solve(rawInput: String): String {
        val cleaned = normalize(rawInput)
        if (cleaned.isBlank()) throw MathError("Nada reconhecido")

        return if (cleaned.contains("=")) {
            solveLinearEquation(cleaned)
        } else {
            val result = ExpressionParser(cleaned).parseFully()
            formatNumber(result)
        }
    }

    /** Normaliza texto vindo do OCR: corrige símbolos comuns lidos errado. */
    private fun normalize(input: String): String {
        var s = input
            .replace(",", ".")
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace(" ", "")

        // 'x' minúsculo só é tratado como multiplicação quando NÃO há '=' na string
        // (se houver '=', tratamos 'x' como a incógnita da equação e o parser cuida do resto).
        if (!s.contains("=")) {
            s = s.replace("x", "*")
        }
        return s
    }

    private fun solveLinearEquation(expr: String): String {
        // Usa 'X' maiúsculo como incógnita para não colidir com o '*' de multiplicação
        val eqExpr = expr.replace("x", "X").replace("*", "*")
        val sides = eqExpr.split("=")
        if (sides.size != 2) throw MathError("Equação inválida")

        // Move tudo para: aX + b = 0  =>  X = -b/a
        val (aLeft, bLeft) = linearCoefficients(sides[0])
        val (aRight, bRight) = linearCoefficients(sides[1])

        val a = aLeft - aRight
        val b = bLeft - bRight

        if (a == 0.0) {
            return if (b == 0.0) "Infinitas soluções" else "Sem solução"
        }
        val x = -b / a
        return "X = ${formatNumber(x)}"
    }

    /** Extrai (coeficiente de X, termo independente) de uma expressão linear simples. */
    private fun linearCoefficients(side: String): Pair<Double, Double> {
        // Substitui X por uma variável simbólica avaliando em dois pontos (X=0 e X=1)
        // f(0) = b ; f(1) = a + b  => a = f(1) - f(0)
        val f0 = ExpressionParser(side.replace("X", "(0)")).parseFully()
        val f1 = ExpressionParser(side.replace("X", "(1)")).parseFully()
        val b = f0
        val a = f1 - f0
        return Pair(a, b)
    }

    private fun formatNumber(d: Double): String {
        if (d.isNaN()) throw MathError("Cálculo inválido")
        if (d.isInfinite()) throw MathError("Divisão por zero")
        return if (abs(d - d.roundToLong()) < 1e-9) {
            d.roundToLong().toString()
        } else {
            // até 6 casas decimais, sem zeros à direita
            var s = "%.6f".format(d)
            s = s.trimEnd('0').trimEnd('.')
            s
        }
    }

    /** Parser recursivo descendente: expr -> termo (+/-) termo ...; termo -> fator (*,/,%) fator; fator -> num | (expr) | func(expr) | -fator | fator^fator */
    private class ExpressionParser(private val input: String) {
        private var pos = 0

        fun parseFully(): Double {
            val result = parseExpression()
            if (pos != input.length) throw MathError("Expressão inválida perto de '${input.substring(pos)}'")
            return result
        }

        private fun parseExpression(): Double {
            var value = parseTerm()
            while (pos < input.length && (peek() == '+' || peek() == '-')) {
                val op = next()
                val rhs = parseTerm()
                value = if (op == '+') value + rhs else value - rhs
            }
            return value
        }

        private fun parseTerm(): Double {
            var value = parseFactor()
            while (pos < input.length && (peek() == '*' || peek() == '/' || peek() == '%')) {
                val op = next()
                val rhs = parseFactor()
                value = when (op) {
                    '*' -> value * rhs
                    '/' -> {
                        if (rhs == 0.0) throw MathError("Divisão por zero")
                        value / rhs
                    }
                    else -> value % rhs
                }
            }
            return value
        }

        private fun parseFactor(): Double {
            if (pos < input.length && peek() == '-') {
                next()
                return -parseFactor()
            }
            if (pos < input.length && peek() == '+') {
                next()
                return parseFactor()
            }
            var value = parseBase()
            if (pos < input.length && peek() == '^') {
                next()
                val exponent = parseFactor()
                value = value.pow(exponent)
            }
            return value
        }

        private fun parseBase(): Double {
            if (pos >= input.length) throw MathError("Expressão incompleta")

            // Parênteses
            if (peek() == '(') {
                next()
                val value = parseExpression()
                if (pos >= input.length || peek() != ')') throw MathError("Parêntese não fechado")
                next()
                return value
            }

            // Funções: sqrt, sin, cos, tan, log, ln
            val funcNames = listOf("sqrt", "sin", "cos", "tan", "log", "ln")
            for (fn in funcNames) {
                if (input.startsWith(fn, pos)) {
                    pos += fn.length
                    if (pos >= input.length || peek() != '(') throw MathError("Esperado '(' após $fn")
                    next()
                    val arg = parseExpression()
                    if (pos >= input.length || peek() != ')') throw MathError("Parêntese não fechado")
                    next()
                    return when (fn) {
                        "sqrt" -> sqrt(arg)
                        "sin" -> sin(Math.toRadians(arg))
                        "cos" -> cos(Math.toRadians(arg))
                        "tan" -> tan(Math.toRadians(arg))
                        "log" -> log10(arg)
                        "ln" -> ln(arg)
                        else -> arg
                    }
                }
            }

            // Número
            val start = pos
            while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
            if (pos == start) throw MathError("Caractere inesperado '${peek()}'")
            return input.substring(start, pos).toDouble()
        }

        private fun peek(): Char = input[pos]
        private fun next(): Char = input[pos++]
    }
}
