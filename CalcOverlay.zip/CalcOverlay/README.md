# Calc Overlay

App Android com **janela flutuante** que fica por cima de qualquer outro app, permite
posicionar uma "mira" sobre uma expressão matemática visível na tela, lê o conteúdo via
**OCR on-device** (ML Kit, funciona offline) e resolve o cálculo, mostrando o resultado
dentro da própria janela.

## O que ele resolve
- Expressões: `+ - * / % ^`, parênteses, `sqrt()`, `sin() cos() tan()` (graus), `log() ln()`
- Equações lineares simples com uma incógnita, ex: `3x + 5 = 20` → `X = 5`

## Como compilar
1. Instale o **Android Studio** (Hedgehog ou mais recente).
2. Abra a pasta `CalcOverlay/` como projeto.
3. Deixe o Gradle sincronizar (vai baixar as dependências do ML Kit e do AndroidX).
4. Conecte seu celular via USB com **Depuração USB** ativada, ou gere um APK
   assinado em `Build > Generate Signed Bundle / APK`.
5. Rode o app.

## Como usar
1. Abra o app e toque em **"Ativar janela flutuante"**.
2. Conceda a permissão **"Aparecer sobre outros apps"** (leva para as Configurações,
   é só ativar e voltar).
3. O sistema vai pedir autorização para **gravar a tela** — isso é necessário para o app
   conseguir "ler" a área marcada. É pedido pelo próprio Android (MediaProjection API),
   não é algo que o app faz escondido.
4. Uma janelinha azul aparece flutuando. Arraste-a pela barra do topo até posicionar
   o miolo sobre o cálculo que você quer resolver.
5. Toque em **"Calcular"**: o app tira um "print" só daquela área, faz o OCR e mostra
   o resultado dentro da própria janela.
6. Toque em **"Fechar"** para encerrar a janela flutuante.

## Permissões usadas e por quê
- `SYSTEM_ALERT_WINDOW`: exibir a janela flutuante sobre outros apps.
- `MediaProjection` (autorizada pelo usuário a cada sessão, é o padrão do Android):
  capturar a região da tela apontada pela janela.
- `FOREGROUND_SERVICE`: manter a janela ativa de forma estável enquanto o app não
  está em primeiro plano.

## Limitações conhecidas / pontos para evoluir
- O parser cobre expressões aritméticas e equações lineares simples; não resolve
  sistemas de equações ou cálculo simbólico avançado (para isso dá pra trocar o
  `MathEvaluator` por uma lib como o `symja` ou `mXparser`).
- O OCR funciona melhor com números "de forma", digitados ou impressos — fontes muito
  estilizadas ou manuscritas podem falhar; nesse caso o app mostra o texto lido para
  você conferir/corrigir.
- Se quiser que o resultado apareça em uma barra de notificação em vez de dentro da
  mira, dá para adaptar o `OverlayService` facilmente.

## Estrutura do projeto
```
CalcOverlay/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/calcoverlay/app/
│       │   ├── MainActivity.kt      # pede permissões e inicia o serviço
│       │   ├── OverlayService.kt    # janela flutuante + captura + OCR
│       │   └── MathEvaluator.kt     # parser de expressões e equações
│       └── res/
│           ├── layout/              # activity_main.xml, overlay_target.xml
│           ├── drawable/            # fundo da janela flutuante
│           └── values/              # strings.xml, themes.xml
├── build.gradle
└── settings.gradle
```
